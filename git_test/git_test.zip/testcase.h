#include "stdafx.h"
#include "SiftEngine.h"
#include "ImageManager.h"
bool getMemoryFromImage(char* fname, Memory& m);
void chang_test();
void chang_cache();